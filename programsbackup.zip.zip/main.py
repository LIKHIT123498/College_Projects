import random
import sys
list=[1,2,3,4,6,0,'out']
total=0
print('Cricket Game')
while True:
    useri=input('Press enter to continue:')
    X=random.choice(list)
    if useri=='':
     print(f'score:',X)
     if type(X)==int:
      total=total+X
     print('Your total score is:',total)
    if X=='out':
        print('Game over')
        print('Your total  is:',total)
